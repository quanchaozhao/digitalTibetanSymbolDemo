﻿1.select_sample.py:从对应的文件夹选择一定数目的样本,用于抽取一定数目的样本和划分训练集和测试集.
2.data_augument.py:数据增加方法,旋转,缩放和增加噪音.
3.construct_map_files.py:从数据集中,生成对应样本的路径和对应的label.
4.words_Titan:藏语编码字典.
5.model文件夹里含有cnn模型和数据读取文件.

